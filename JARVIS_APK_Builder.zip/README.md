# JARVIS APK Builder

This project wraps the existing JARVIS Command Center web app in an Android WebView.

Build:
1. Push this folder to a GitHub repository.
2. GitHub Actions will build `app-debug.apk`.
3. Download the APK from the workflow artifact.

Note: the current JARVIS web URL is embedded in MainActivity.kt. If the web app URL changes, update `startUrl`.
