package com.ankur.ultron

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            speak("Microphone permission is required for voice commands.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
            }
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            // The UI will still work; voice recognition depends on a speech service
            // being available on the device.
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            UltronApp(
                onListen = { startListening { command -> handleCommand(command) } },
                onStop = { stopListening() }
            )
        }
    }

    private fun startListening(onResult: (String) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(SimpleRecognitionListener(
                onResult = onResult,
                onError = { speak("I could not understand that. Please try again.") }
            ))
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun stopListening() {
        recognizer?.stopListening()
        recognizer?.destroy()
        recognizer = null
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) return

        val normalized = command.lowercase(Locale.getDefault())
        when {
            normalized.contains("ultron") && normalized.contains("wake") ->
                speak("I am awake and ready.")
            normalized.contains("hello") || normalized.contains("hi ultron") ->
                speak("Hello. I am Ultron. How can I help?")
            normalized.contains("time") ->
                speak("The current time is ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())}.")
            normalized.contains("open youtube") ->
                openUrl("https://www.youtube.com")
            normalized.contains("open github") ->
                openUrl("https://github.com")
            else ->
                speak("Command received: $command. AI execution will be connected in the next module.")
        }
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ULTRON")
    }

    override fun onDestroy() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private class SimpleRecognitionListener(
    private val onResult: (String) -> Unit,
    private val onError: () -> Unit
) : android.speech.RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val best = matches?.firstOrNull()
        if (best != null) onResult(best) else onError()
    }

    override fun onError(error: Int) = onError()
}

@Composable
fun UltronApp(onListen: () -> Unit, onStop: () -> Unit) {
    var status by remember { mutableStateOf("SYSTEM ONLINE") }
    var listening by remember { mutableStateOf(false) }
    var lastCommand by remember { mutableStateOf("No command yet") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF05070A),
            surface = Color(0xFF0A1017),
            primary = Color(0xFF00D9FF),
            secondary = Color(0xFF6A7CFF)
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(Color(0xFF05070A)).padding(18.dp)
        ) {
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "ULTRON",
                    color = Color(0xFF00D9FF),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "PERSONAL • AI • BUSINESS ASSISTANT",
                    color = Color(0xFF7B8B99),
                    fontSize = 11.sp
                )

                Spacer(Modifier.height(24.dp))

                Box(
                    Modifier.size(230.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier.size(190.dp),
                        shape = CircleShape,
                        color = Color(0xFF07131A),
                        tonalElevation = 10.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                if (listening) "LISTENING" else "U",
                                color = Color(0xFF00D9FF),
                                fontSize = if (listening) 18.sp else 72.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Text(status, color = Color(0xFF00D9FF), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1017)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text("LAST COMMAND", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(lastCommand, color = Color(0xFF9EB0BC))
                        Spacer(Modifier.height(12.dp))
                        Text("Voice recognition • Hindi / English / device languages",
                            color = Color(0xFF9EB0BC), fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.weight(1f))

                Button(
                    onClick = {
                        if (listening) {
                            onStop()
                            listening = false
                            status = "SYSTEM ONLINE"
                        } else {
                            onListen()
                            listening = true
                            status = "MIC ACTIVE • SPEAK NOW"
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        if (listening) "STOP LISTENING" else "ACTIVATE ULTRON",
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}
